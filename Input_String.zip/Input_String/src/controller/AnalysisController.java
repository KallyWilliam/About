package controller;

import model.AnalysisModel;
import view.AnalysisView;
import java.util.HashMap;
import java.util.List;

public class AnalysisController {
    private AnalysisModel model;
    private AnalysisView view;

    public AnalysisController(AnalysisModel model, AnalysisView view) {
        this.model = model;
        this.view = view;
    }

    public void analyzeString() {
        String input = view.getUserInput();
        int charCount = input.length();
        HashMap<String, List<Integer>> numberAnalysis = model.getNumber(input);
        HashMap<String, StringBuilder> characterAnalysis = model.getCharacter(input);

        view.displayResult(charCount, numberAnalysis, characterAnalysis);
    }
}
