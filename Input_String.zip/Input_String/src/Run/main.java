package Run;

import controller.AnalysisController;
import model.AnalysisModel;
import view.AnalysisView;

public class main {
    public static void main(String[] args) {
        AnalysisModel model = new AnalysisModel();
        AnalysisView view = new AnalysisView();
        AnalysisController controller = new AnalysisController(model, view); 

        controller.analyzeString(); 
    }
}
