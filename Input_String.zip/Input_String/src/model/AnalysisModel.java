package model;

import java.util.*;
import java.util.regex.*;
import java.util.stream.Collectors;

public class AnalysisModel {
    public HashMap<String, List<Integer>> getNumber(String input) {
        HashMap<String, List<Integer>> result = new HashMap<>();
        List<Integer> allNumbers = new ArrayList<>();
        List<Integer> evenNumbers = new ArrayList<>();
        List<Integer> oddNumbers = new ArrayList<>();
        List<Integer> perfectsquareNumbers = new ArrayList<>();

        // Regular expression to match numbers
        String numberPattern = "\\d+";
        Matcher matcher = Pattern.compile(numberPattern).matcher(input);

        while (matcher.find()) {
            int number = Integer.parseInt(matcher.group());
            allNumbers.add(number);
            if (number % 2 == 0) {
                evenNumbers.add(number);
            } else {
                oddNumbers.add(number);
            }
            if (isPerfectSquare(number)) {
                perfectsquareNumbers.add(number);
            }
        }

        result.put("All Numbers", allNumbers);
        result.put("Even Numbers", evenNumbers);
        result.put("Odd Numbers", oddNumbers);
        result.put("Perfect Square Numbers", perfectsquareNumbers);
        return result;
    }

   public HashMap<String, StringBuilder> getCharacter(String input) {
    HashMap<String, StringBuilder> result = new HashMap<>();
    StringBuilder allChars = new StringBuilder();
    StringBuilder specialChars = new StringBuilder();
    StringBuilder upperCaseChars = new StringBuilder();
    StringBuilder lowerCaseChars = new StringBuilder();

    for (char c : input.toCharArray()) {
        if (!Character.isDigit(c)) {
            allChars.append(c);
        }
        if (Character.isUpperCase(c)) {
            upperCaseChars.append(c);
        } else if (Character.isLowerCase(c)) {
            lowerCaseChars.append(c);
        }
        if (!Character.isLetterOrDigit(c) && !Character.isWhitespace(c)) {
            specialChars.append(c);
        }
    }

    result.put("All Characters", allChars);
    result.put("Special Characters", specialChars);
    result.put("Uppercase Characters", upperCaseChars);
    result.put("Lowercase Characters", lowerCaseChars);
    return result;
}


private boolean isPerfectSquare(int number) {
    double sqrt = Math.sqrt(number);
    return sqrt == (int) sqrt;
}




}
