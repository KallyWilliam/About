package view;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class AnalysisView {
    public void displayResult(int charCount, HashMap<String, List<Integer>> numberAnalysis, HashMap<String, StringBuilder> characterAnalysis) {
        System.out.println("Analysis Results:");
        System.out.println("Number of characters in the string: " + charCount);

        System.out.println("\nNumbers:");
        for (Map.Entry<String, List<Integer>> entry : numberAnalysis.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue());
        }

        System.out.println("\nCharacters:");
        for (Map.Entry<String, StringBuilder> entry : characterAnalysis.entrySet()) {
            System.out.println(entry.getKey() + ": " + entry.getValue().toString());
        }
    }

    public String getUserInput() {
        System.out.print("Enter a string: ");
        return new Scanner(System.in).nextLine();
    }
}
