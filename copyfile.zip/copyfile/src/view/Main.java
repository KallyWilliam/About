package view;

import controller.Display;

public class Main {

    public static void main(String[] args) {
        Display d = new Display();
        d.run();
    }
}
