package Validation;


public interface ValidationChecker<E> {

    /**
     * Callback for check validation
     *
     * @param value
     * @return true | false
     */
    boolean checker(E value);
}