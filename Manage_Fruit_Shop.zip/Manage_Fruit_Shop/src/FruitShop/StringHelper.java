/*
 * Copyright 2022 QuangTDHE16060
 * https://github.com/quang2002
 */
package FruitShop;

/**
 *
 * @author yuyu
 */
public class StringHelper {

    /**
     * Make a string into align center form
     *
     * @param spacing number of spacing for string display
     * @param obj object that need to align center
     * @return a string with the content fit in center of the string, if the
     * content has length greater than 'spacing', then put all available content
     * in that spacing and ending with '...'
     */
    public static String center(int spacing, Object obj) {
        // get content from object by toString method
        String text = obj.toString();

        // if length of content greater than spacing
        if (text.length() > spacing) {
            // return with available content ending with ...
            return text.substring(0, spacing - 3).concat("...");
        }

        // otherwise calculate number of spaces covered the content
        int spaces = spacing - text.length();
        return String.format("%" + (spaces / 2) + "s%s%" + (spaces - spaces / 2) + "s", "", text, "");
    }
}