package Data;

public class DataFile {
    public static final String PERSON_DATA_FILE = "D:\\FPTU\\LAB\\Handle_File\\src\\data\\Test.txt\";";
}
