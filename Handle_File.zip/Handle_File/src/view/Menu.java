package view;

import controller.PersonController;
import java.io.IOException;
import java.util.Scanner;

public class Menu {
    private Scanner scanner;

    public Menu() {
        scanner = new Scanner(System.in);
    }

    public int displayMainMenu() {
        System.out.println("Menu:");
        System.out.println("1. Tìm thông tin cá nhân");
        System.out.println("2. Sao chép từ vào tệp mới");
        System.out.println("3. Thoát");
        System.out.print("Chọn một tùy chọn: ");
        return scanner.nextInt();
    }

    public void displaySubMenu(String message) {
        System.out.println(message);
    }

    public String getInputPath(String message) {
        System.out.print(message);
        scanner.nextLine();
        return scanner.nextLine();
    }

    public double getMinSalary(String message) {
        System.out.print(message);
        return scanner.nextDouble();
    }

    public String getSourcePath(String message) {
        System.out.print(message);
        scanner.nextLine();
        return scanner.nextLine();
    }

    public String getDestinationPath(String message) {
        System.out.print(message);
        return scanner.nextLine();
    }
}


