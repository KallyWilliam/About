package view;
import Data.Person;
import java.util.List;
import java.util.Scanner;

public class PersonView {
    private Scanner scanner;

    public PersonView() {
        scanner = new Scanner(System.in);
    }

    public int displayMenu() {
        System.out.println("Menu:");
        System.out.println("1. Tìm thông tin cá nhân");
        System.out.println("2. Sao chép từ vào tệp mới");
        System.out.println("3. Thoát");
        System.out.print("Chọn một tùy chọn: ");
        return scanner.nextInt();
    }

    public String getInputPath() {
        System.out.print("Nhập đường dẫn của tệp văn bản: ");
        scanner.nextLine();
        return scanner.nextLine();
    }

    public double getMinSalary() {
        System.out.print("Nhập mức lương tối thiểu: ");
        return scanner.nextDouble();
    }

    public String getSourcePath() {
        System.out.print("Nhập đường dẫn của tệp nguồn: ");
        scanner.nextLine();
        return scanner.nextLine();
    }

    public String getDestinationPath() {
        System.out.print("Nhập đường dẫn của tệp đích: ");
        return scanner.nextLine();
    }

    public void displayPeople(List<Person> people) {
        if (people.isEmpty()) {
            System.out.println("Không có người nào thỏa mãn điều kiện.");
        } else {
            System.out.println("Những người có mức lương lớn hơn hoặc bằng mức lương tối thiểu:");
            for (Person person : people) {
                System.out.println(person);
            }
        }
    }

    public void displayCopySuccess() {
        System.out.println("Tạo tệp mới thành công.");
    }

    public void displayError(String message) {
        System.out.println("Lỗi: " + message);
    }
}
