package controller;


import view.Menu;
import model.PersonModel;
import Data.Person;
import java.io.IOException;
import java.util.List;


public class PersonController {
    // public static final String PERSON_DATA_FILE = "D:\\FPTU\\LAB\\Handle_File\\src\\data\\Test.txt\";";
    private Menu menu;
    private PersonModel model;

    public PersonController(Menu menu) {
        this.menu = menu;
        model = new PersonModel();
    }

    public void run() throws IOException {
        while (true) {
            int choice = menu.displayMainMenu();

            switch (choice) {
                case 1:
                    String filePath = menu.getInputPath("Nhập đường dẫn của tệp văn bản: ");
                    double minSalary = menu.getMinSalary("Nhập mức lương tối thiểu: ");

                    List<Person> people = model.getPerson(filePath, minSalary);
                    menu.displaySubMenu("Những người có mức lương lớn hơn hoặc bằng " + minSalary + ":");
                    for (Person person : people) {
                        menu.displaySubMenu(person.toString());
                    }

                    break;

                case 2:
                    String sourceFilePath = menu.getSourcePath("Nhập đường dẫn của tệp nguồn: ");
                    String destinationFilePath = menu.getDestinationPath("Nhập đường dẫn của tệp đích: ");

                    try {
                        if (model.copyUniqueWords(sourceFilePath, destinationFilePath)) {
                            menu.displaySubMenu("Tạo tệp mới thành công.");
                        } else {
                            menu.displaySubMenu("Lỗi khi tạo tệp mới.");
                        }
                    } catch (Exception e) {
                        menu.displaySubMenu("Lỗi: " + e.getMessage());
                    }

                    break;

                case 3:
                    System.exit(0);
                    break;

                default:
                    menu.displaySubMenu("Lựa chọn không hợp lệ. Vui lòng chọn lại.");
                    break;
            }
        }
    }
}
