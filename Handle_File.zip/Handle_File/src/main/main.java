package main;
import controller.PersonController;
import java.io.IOException;
import view.Menu;

class Main {
    public static void main(String[] args) throws IOException {
        Menu menu = new Menu();
        PersonController controller = new PersonController(menu);

        controller.run();
    }
}