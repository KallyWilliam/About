package model;



import Data.Person;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class PersonModel {
    public List<Person> getPerson(String path, double minSalary) throws IOException {
        List<Person> people = new ArrayList<>();

        try (BufferedReader br = new BufferedReader(new FileReader(path))) {
            String line;
            while ((line = br.readLine()) != null) {
                String[] parts = line.split(";");
                if (parts.length == 3) {
                    try {
                        String name = parts[0];
                        String address = parts[1];
                        double salary = Double.parseDouble(parts[2]);
                        if (salary < 0) {
                            salary = 0;
                        }
                        people.add(new Person(name, address, salary));
                    } catch (NumberFormatException e) {
                        people.add(new Person(parts[0], parts[1], 0));
                    }
                }
            }
        }

        if (!people.isEmpty()) {
            // Sort the list by salary
            Collections.sort(people, new Comparator<Person>() {
                @Override
                public int compare(Person p1, Person p2) {
                    return Double.compare(p2.getSalary(), p1.getSalary());
                }
            });
        }

        return people;
    }

    public boolean copyUniqueWords(String source, String destination) throws Exception {
        File sourceFile = new File(source);
        File destFile = new File(destination);

        if (!sourceFile.exists()) {
            throw new Exception("Đường dẫn nguồn không tồn tại.");
        }

        try (BufferedReader reader = new BufferedReader(new FileReader(sourceFile));
             BufferedWriter writer = new BufferedWriter(new FileWriter(destFile))) {
            List<String> words = new ArrayList<>();
            String line;
            while ((line = reader.readLine()) != null) {
                String[] wordArray = line.split("\\s+");
                for (String word : wordArray) {
                    if (!words.contains(word)) {
                        words.add(word);
                        writer.write(word + " ");
                    }
                }
            }
        }

        return true;
    }
}
