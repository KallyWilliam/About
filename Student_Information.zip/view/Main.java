// view/Main.java
package view;

import controller.StudentController;

public class Main {
    public static void main(String[] args) {
        StudentController controller = new StudentController();
        controller.start();
    }
}
