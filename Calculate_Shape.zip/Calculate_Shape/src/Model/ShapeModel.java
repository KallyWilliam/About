package Model;

public class ShapeModel {
    private double width;
    private double length;
    private double radius;
    private double sideA;
    private double sideB;
    private double sideC;

    public void setRectangle(double width, double length) {
        this.width = width;
        this.length = length;
    }

    public void setCircle(double radius) {
        this.radius = radius;
    }

    public void setTriangle(double sideA, double sideB, double sideC) {
        this.sideA = sideA;
        this.sideB = sideB;
        this.sideC = sideC;
    }

    public double getRectanglePerimeter() {
        return 2 * (width + length);
    }

    public double getRectangleArea() {
        return width * length;
    }

    public double getCirclePerimeter() {
        return 2 * Math.PI * radius;
    }

    public double getCircleArea() {
        return Math.PI * radius * radius;
    }

    public double getTrianglePerimeter() {
        return sideA + sideB + sideC;
    }

    public double getTriangleArea() {
        double p = getTrianglePerimeter() / 2;
        return Math.sqrt(p * (p - sideA) * (p - sideB) * (p - sideC));
    }
}
