package View;

import java.util.Scanner;

public class ShapeView {
    public int displayMenu(Scanner input) {
        System.out.println("Select a shape: 1 for Circle, 2 for Rectangle, 3 for Triangle");
        return input.nextInt();
    }

    public double inputRadius(Scanner input) {
        System.out.print("Enter the radius of the Circle: ");
        return input.nextDouble();
    }

    public double inputWidth(Scanner input) {
        System.out.print("Enter the width of the Rectangle: ");
        return input.nextDouble();
    }

    public double inputLength(Scanner input) {
        System.out.print("Enter the length of the Rectangle: ");
        return input.nextDouble();
    }

    public double inputSideA(Scanner input) {
        System.out.print("Enter side A of the Triangle: ");
        return input.nextDouble();
    }

    public double inputSideB(Scanner input) {
        System.out.print("Enter side B of the Triangle: ");
        return input.nextDouble();
    }

    public double inputSideC(Scanner input) {
        System.out.print("Enter side C of the Triangle: ");
        return input.nextDouble();
    }

    public void printResult(String shapeName, double perimeter, double area) {
        System.out.println(shapeName + ":");
        System.out.println("Perimeter: " + perimeter);
        System.out.println("Area: " + area);
    }
}
