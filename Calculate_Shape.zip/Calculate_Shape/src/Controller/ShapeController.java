package Controller;

import Model.ShapeModel;
import View.ShapeView;
import java.util.Scanner;

public class ShapeController {
    private ShapeModel model;
    private ShapeView view;

    public ShapeController(ShapeModel model, ShapeView view) {
        this.model = model;
        this.view = view;
    }

    public void processShape() {
        Scanner input = new Scanner(System.in);
        int choice = view.displayMenu(input);

        switch (choice) {
            case 1:
                double radius = view.inputRadius(input);
                model.setCircle(radius);
                double circlePerimeter = model.getCirclePerimeter();
                double circleArea = model.getCircleArea();
                view.printResult("Circle", circlePerimeter, circleArea);
                break;
            case 2:
                double width = view.inputWidth(input);
                double length = view.inputLength(input);
                model.setRectangle(width, length);
                double rectanglePerimeter = model.getRectanglePerimeter();
                double rectangleArea = model.getRectangleArea();
                view.printResult("Rectangle", rectanglePerimeter, rectangleArea);
                break;
            case 3:
                double sideA = view.inputSideA(input);
                double sideB = view.inputSideB(input);
                double sideC = view.inputSideC(input);
                model.setTriangle(sideA, sideB, sideC);
                double trianglePerimeter = model.getTrianglePerimeter();
                double triangleArea = model.getTriangleArea();
                view.printResult("Triangle", trianglePerimeter, triangleArea);
                break;
            default:
                System.out.println("Invalid choice");
        }
    }
}
