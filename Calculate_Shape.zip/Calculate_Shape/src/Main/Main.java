package Main;

import Controller.ShapeController;
import Model.ShapeModel;
import View.ShapeView;
import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Menu mainMenu = new Menu();

        while (true) {
            int choice = mainMenu.displayMainMenu(input);

            if (choice == 1) {
                calculateShape(input);
            } else if (choice == 2) {
                System.out.println("Exiting the program.");
                break;
            } else {
                System.out.println("Invalid choice. Please select a valid option.");
            }
        }
    }

    public static void calculateShape(Scanner input) {
        ShapeModel model = new ShapeModel();
        ShapeView view = new ShapeView();
        ShapeController controller = new ShapeController(model, view);

        controller.processShape();
    }
}
