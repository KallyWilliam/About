package Main;

import java.util.Scanner;

public class Menu {
    public int displayMainMenu(Scanner input) {
        System.out.println("Select an option:");
        System.out.println("1. Calculate Shape");
        System.out.println("2. Exit");
        return input.nextInt();
    }
}

