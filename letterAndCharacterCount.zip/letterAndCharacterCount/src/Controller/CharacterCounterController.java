package Controller;

import Model.CharacterCounterModel;
import View.CharacterCounterView;
import java.util.Map;

public class CharacterCounterController {

    private CharacterCounterModel model;
    private CharacterCounterView view;

    public CharacterCounterController(CharacterCounterModel model, CharacterCounterView view) {
        this.model = model;
        this.view = view;
    }

    public void processInputString(String inputString) {
        model.setInputString(inputString);
        model.countCharacters();
        model.countWords();
        Map<Character, Integer> characterCounts = model.getCharacterCounts();
        Map<String, Integer> wordCounts = model.getWordCounts();

        view.displayResult(inputString, characterCounts, wordCounts);
    }
}

