/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package View;

import java.util.Map;
/**
 *
 * @author ADMIN
 */
public class CharacterCounterView {
    public void displayResult(String inputString, Map<Character, Integer> characterCounts, Map<String, Integer> wordCounts) {
        System.out.println(inputString);
        System.out.println("Character Counts: " + characterCounts);
        System.out.println("Word Counts: " + wordCounts);
    }
}





    
