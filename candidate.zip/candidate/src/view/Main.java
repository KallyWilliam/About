package view;


import controller.Candidate;
import java.util.ArrayList;

public class Main {

    public static void main(String[] args) {
        ArrayList<Candidate> candidates = new ArrayList<>();
        
        while (true) {
            int choice = Manager.menu();
            switch (choice) {
                case 1:
                    Manager.createCandidate(candidates, 0);
                    break;
                case 2:
                    Manager.createCandidate(candidates, 1);
                    break;
                case 3:
                    Manager.createCandidate(candidates, 2);
                    break;
                case 4:
                    Manager.searchCandidate(candidates);
                    break;
                case 5:
                    return;
            }
        }
    }

//    private static class Manager {
//
//        private static void createCandidate(ArrayList<Candidate> candidates, int i) {
//        }
//
//        private static void searchCandidate(ArrayList<Candidate> candidates) {
//        }
//
//        private static int menu() {
//            return 0;
//        }
//        public Manager() {
//        }
//    }
}