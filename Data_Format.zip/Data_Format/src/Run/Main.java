package Run;

import controller.FormatCheckerController;


public class Main {
    public static void main(String[] args) {
        FormatCheckerController controller = new FormatCheckerController();
        controller.run();
    }
}
