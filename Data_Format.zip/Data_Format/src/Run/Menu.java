package run;

import Common.Validation;
import java.util.ArrayList;

public abstract class Menu<T> {
    private String title;
    private ArrayList<T> mChon;   
    private Validation validation;
        
    public Menu(String td, String[] mc) {
        title = td;
        validation= new Validation();
        mChon = new ArrayList<>();
        for (String s : mc) {
            mChon.add((T) s);
        }
    }

    //-------------------------------------------
    public void display() {
        System.out.println(title);
        System.out.println("--------------------------------");
        for (int i = 0; i < mChon.size(); i++) {
            System.out.println((i + 1) + "." + mChon.get(i));
        }
        System.out.println("--------------------------------");
    }
//-------------------------------------------

    public int getSelected() {
        display();
        System.out.print("Enter your choice: ");
        return validation.checkInputIntLimit(1, mChon.size());
    }
//-------------------------------------------

    public abstract void execute(int n);
//-------------------------------------------

    public void run() {
        while (true) {
            int n = getSelected();            
            execute(n);   
            if (n > mChon.size()-1) {
                break;
            }
        }
    }
}
