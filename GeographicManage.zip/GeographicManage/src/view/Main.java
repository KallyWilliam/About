package view;

import controller.ManageEastAsiaCountriesController;

public class Main {
    public static void main(String[] args) {
        ManageEastAsiaCountriesController controller = new ManageEastAsiaCountriesController();
        controller.runApplication();
    }
}