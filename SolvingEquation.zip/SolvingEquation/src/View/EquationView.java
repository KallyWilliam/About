package view;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class EquationView {

    private Scanner scanner;

    public EquationView() {
        scanner = new Scanner(System.in);
    }

    public void displayMenu() {
        System.out.println("========= Equation Program =========");
        System.out.println("1. Calculate Superlative Equation");
        System.out.println("2. Calculate Quadratic Equation");
        System.out.println("3. Exit");
    }

    public double inputCoefficient(String coefficientName) {
        double coefficient = 0.0;
        boolean validInput = false;

        while (!validInput) {
            System.out.print("Enter " + coefficientName + ": ");
            if (scanner.hasNextDouble()) {
                coefficient = scanner.nextDouble();
                validInput = true;
            } else {
                System.out.println("Please input a valid number.");
                scanner.next();
            }
        }

        return coefficient;
    }

public void calculateSuperlativeEquation(double a, double b) {
    double result;

    if (a == 0) {
        if (b == 0) {
            System.out.println("Infinite solutions");
        } else {
            System.out.println("No solution");
        }
    } else {
        result = -b / a;
        System.out.println("Solution: x = " + String.format("%.3f", result));
        findAndDisplaySpecialNumbers(a, b, result);
    }
}


public void calculateQuadraticEquation(double a, double b, double c) {
    double discriminant = b * b - 4 * a * c;

    if (a == 0) {
        System.out.println("This is not a quadratic equation.");
    } else if (discriminant < 0) {
        System.out.println("No real solutions");
    } else if (discriminant == 0) {
        double result = -b / (2 * a);
        System.out.println("Solution: x = " + String.format("%.3f", result));
        findAndDisplaySpecialNumbers(a, b, c, result);
    } else {
        double result1 = (-b + Math.sqrt(discriminant)) / (2 * a);
        double result2 = (-b - Math.sqrt(discriminant)) / (2 * a);
        if (Math.abs(result1 - result2) < 1e-6) {
            System.out.println("Solutions: x1 = x2 = " + String.format("%.3f", result1));
        } else {
            System.out.println("Solutions: x1 = " + String.format("%.3f", result1) + " and x2 = " + String.format("%.3f", result2));
        }
        findAndDisplaySpecialNumbers(a, b, c, result1, result2);
    }
}


    public void findAndDisplaySpecialNumbers(double... numbers) {
        List<Double> oddNumbers = new ArrayList<>();
        List<Double> evenNumbers = new ArrayList<>();
        List<Double> squareNumbers = new ArrayList<>();

        for (double num : numbers) {
            if (isOdd(num)) {
                oddNumbers.add(num);
            } else {
                evenNumbers.add(num);
            }
            if (isPerfectSquare(num)) {
                squareNumbers.add(num);
            }
        }

        System.out.println("Odd Number(s): " + oddNumbers);
        System.out.println("Even Number(s): " + evenNumbers);
        System.out.println("Number is Perfect Square: " + squareNumbers);
    }

    private boolean isOdd(double number) {
        return number % 2 != 0;
    }

    private boolean isPerfectSquare(double number) {
        double sqrt = Math.sqrt(number);
        return sqrt == (int) sqrt;
    }

    public void closeScanner() {
        scanner.close();
    }

    public int inputInt(String message) {
        System.out.print(message + ": ");
        int choice = scanner.nextInt();
        return choice;
    }

    public void displayMessage(String message) {
        System.out.println(message);
    }

}
