package view;

import controller.EquationController;

public class EquationSolverMain {
    public static void main(String[] args) {
        EquationController controller = new EquationController(new EquationView());

        controller.run();
    }
}

