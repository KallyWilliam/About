package model;

import Model.EquationModel;
import java.util.ArrayList;
import java.util.List;

public class QuadraticEquation extends EquationModel {
    private double a;
    private double b;
    private double c;

    public QuadraticEquation(double a, double b, double c) {
        this.a = a;
        this.b = b;
        this.c = c;
    }

    @Override
    public List<Double> calculate() {
        List<Double> result = new ArrayList<>();
        if (a == 0) {
            result.add(Double.NaN); // No solution
        } else {
            double discriminant = b * b - 4 * a * c;
            if (discriminant > 0) {
                double x1 = (-b + Math.sqrt(discriminant)) / (2 * a);
                double x2 = (-b - Math.sqrt(discriminant)) / (2 * a);
                result.add(x1);
                result.add(x2);
            } else if (discriminant == 0) {
                double x = -b / (2 * a);
                result.add(x);
            } else {
                result.add(Double.NaN); // No real solution
            }
        }
        return result;
    }
}
