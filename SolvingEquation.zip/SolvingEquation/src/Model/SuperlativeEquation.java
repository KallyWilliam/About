package model;

import Model.EquationModel;
import java.util.ArrayList;
import java.util.List;

public class SuperlativeEquation extends EquationModel {
    private double a;
    private double b;

    public SuperlativeEquation(double a1, double b1) {
        this.a = a;
        this.b = b;
    }

    @Override
    public List<Double> calculate() {
        List<Double> result = new ArrayList<>();
        if (a == 0) {
            result.add(Double.NaN); // No solution
        } else {
            double x = -b / a;
            result.add(x);
        }
        return result;
    }
}
