package Model;

import java.util.ArrayList;
import java.util.List;

public abstract class EquationModel {

    public abstract List<Double> calculate();

    public List<Double> findSpecialNumbers(double... numbers) {
        List<Double> specialNumbers = new ArrayList<>();

        for (double num : numbers) {
            if (isOdd(num)) {
                specialNumbers.add(num);
            }
            if (isEven(num)) {
                specialNumbers.add(num);
            }
            if (isPerfectSquare(num)) {
                specialNumbers.add(num);
            }
        }

        return specialNumbers;
    }

    private boolean isOdd(double number) {
        return number % 2 != 0;
    }

    private boolean isEven(double number) {
        return number % 2 == 0;
    }

    private boolean isPerfectSquare(double number) {
        double sqrt = Math.sqrt(number);
        return sqrt == (int) sqrt;
    }
}
