package controller;

import Model.EquationModel;
import model.QuadraticEquation;
import model.SuperlativeEquation;
import view.EquationView;

public class EquationController {
    private EquationView view;
    private EquationModel model;

    public EquationController(EquationView view) {
        this.view = view;
    }

    public void run() {
        while (true) {
            view.displayMenu();
            int choice = view.inputInt("Please choose an option");

            switch (choice) {
                case 1:
                    double a = view.inputCoefficient("A");
                    double b = view.inputCoefficient("B");
                    model = new SuperlativeEquation(a, b);

                    // Calculate and display Superlative Equation results
                    view.calculateSuperlativeEquation(a, b);
                    break;
                case 2:
                    double quadraticA = view.inputCoefficient("A");
                    double quadraticB = view.inputCoefficient("B");
                    double quadraticC = view.inputCoefficient("C");
                    model = new QuadraticEquation(quadraticA, quadraticB, quadraticC);

                    // Calculate and display Quadratic Equation results
                    view.calculateQuadraticEquation(quadraticA, quadraticB, quadraticC);
                    break;
                case 3:
                    view.displayMessage("Exiting the program.");
                    view.closeScanner();
                    return;
                default:
                    view.displayMessage("Invalid option. Please select a valid option.");
                    break;
            }
        }
    }
}
